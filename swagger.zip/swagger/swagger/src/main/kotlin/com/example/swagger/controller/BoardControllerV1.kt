package com.example.swagger.controller

import io.swagger.annotations.*
import org.springframework.web.bind.annotation.*

@RestController
@Api(value = "BoardController V1")
@RequestMapping("/v1/api")
class BoardControllerV1 {

    @ApiOperation(value = "get", notes = "예제입니다.")
    @GetMapping("/board")
    fun selectOneBoard(@ApiParam(value = "게시판 번호", required = true, example = "1") @RequestParam no:String?): HashMap<String?, String?> {
        var result = HashMap<String?, String?>()
        result["author"] = "hyeok"
        result["content"] = "V1 API 내용"
        return result
    }

    @ApiOperation(value = "post", notes = "예제입니다.")
    @PostMapping("/board")
    fun insertOneBoard(@ApiParam(value = "게시판 번호", required = true, example = "1") @RequestParam no:String?): HashMap<String?, String?> {
        var result = HashMap<String?, String?>()
        result["author"] = "hyeok"
        result["content"] = "V1 API 내용"
        return result
    }

    @ApiOperation(value = "put", notes = "예제입니다.")
    @PutMapping("/board")
    fun updateOneBoard(@ApiParam(value = "게시판 번호", required = true, example = "1") @RequestParam no: String?): HashMap<String?, String?> {
        var result = HashMap<String?, String?>()
        result["author"] = "hyeok"
        result["content"] = "V1 API 내용"
        return result
    }

    @ApiOperation(value = "delete", notes = "예제입니다.")
    @DeleteMapping("/board")
    fun deleteOneBoard(@ApiParam(value = "게시판 번호", required = true, example = "1") @RequestParam no: String?) : HashMap<String?, String?> {
        var result = HashMap<String?, String?>()
        result["author"] = "hyeok"
        result["content"] = "V1 API 내용"
        return result
    }

}